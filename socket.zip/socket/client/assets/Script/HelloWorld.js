cc.Class({
    extends: cc.Component,

    properties: {

        // defaults, set visually when attaching this script to the Canvas

    },

    // use this for initialization
    onLoad: function () {
        this.load()
    },

    // called every frame
    update: function (dt) {

    },
    load(){
        window.io = require('socket.io');
        var socket = io("ws://localhost:3000");
        console.log(socket);
        socket.on('connection', function (data) {
            console.log(data,"发扣扣上");
            // socket.emit('my other event', { my: 'data' });
        });
    },
    //登录
    login(){

    },
    //注册
    registered(){

    },
});

"use strict";
cc._RF.push(module, '280c3rsZJJKnZ9RqbALVwtK', 'HelloWorld');
// Script/HelloWorld.js

'use strict';

cc.Class({
    extends: cc.Component,

    properties: {

        // defaults, set visually when attaching this script to the Canvas

    },

    // use this for initialization
    onLoad: function onLoad() {
        this.load();
    },

    // called every frame
    update: function update(dt) {},
    load: function load() {
        window.io = require('socket.io');
        var socket = io("ws://localhost:3000");
        console.log(socket);
        socket.on('connection', function (data) {
            console.log(data, "发扣扣上");
            // socket.emit('my other event', { my: 'data' });
        });
    },

    //登录
    login: function login() {},

    //注册
    registered: function registered() {}
});

cc._RF.pop();
(function() {"use strict";var __module = CC_EDITOR ? module : {exports:{}};var __filename = 'preview-scripts/assets/Script/HelloWorld.js';var __require = CC_EDITOR ? function (request) {return cc.require(request, require);} : function (request) {return cc.require(request, __filename);};function __define (exports, require, module) {"use strict";
cc._RF.push(module, '280c3rsZJJKnZ9RqbALVwtK', 'HelloWorld', __filename);
// Script/HelloWorld.js

'use strict';

cc.Class({
    extends: cc.Component,

    properties: {

        // defaults, set visually when attaching this script to the Canvas

    },

    // use this for initialization
    onLoad: function onLoad() {
        this.load();
    },

    // called every frame
    update: function update(dt) {},
    load: function load() {
        window.io = require('socket.io');
        var socket = io("ws://localhost:3000");
        console.log(socket);
        socket.on('connection', function (data) {
            console.log(data, "发扣扣上");
            // socket.emit('my other event', { my: 'data' });
        });
    },

    //登录
    login: function login() {},

    //注册
    registered: function registered() {}
});

cc._RF.pop();
        }
        if (CC_EDITOR) {
            __define(__module.exports, __require, __module);
        }
        else {
            cc.registerModuleFunc(__filename, function () {
                __define(__module.exports, __require, __module);
            });
        }
        })();
        //# sourceMappingURL=HelloWorld.js.map
        